const express = require('express');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');

const app = express();
app.use(express.json());

// Allow CORS for Flutter app
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

let sock = null;
let pairingCode = null;
let isConnected = false;
let isPairing = false; // منع إعادة الاتصال أثناء الربط

const logger = pino({ level: 'silent' });

// الصفحة الرئيسية
app.get('/', (req, res) => {
    res.json({
        name: 'Ghazali WhatsApp Server',
        version: '1.0.0',
        status: isConnected ? 'متصل' : (isPairing ? 'جاري الربط' : 'غير متصل'),
        endpoints: {
            status: 'GET /status',
            connect: 'POST /connect',
            send: 'POST /send',
            sendBulk: 'POST /send-bulk',
            disconnect: 'POST /disconnect',
            reset: 'POST /reset'
        }
    });
});

// حالة الاتصال
app.get('/status', (req, res) => {
    res.json({
        connected: isConnected,
        pairingCode: pairingCode
    });
});

// بدء الاتصال مع كود الربط
app.post('/connect', async (req, res) => {
    const { phoneNumber } = req.body;

    if (!phoneNumber) {
        return res.status(400).json({ error: 'Phone number required' });
    }

    try {
        await startConnection(phoneNumber);

        // انتظار توليد الكود
        let attempts = 0;
        while (!pairingCode && attempts < 30) {
            await new Promise(r => setTimeout(r, 1000));
            attempts++;
        }

        if (pairingCode) {
            res.json({
                success: true,
                pairingCode: pairingCode,
                message: 'أدخل هذا الكود في واتساب > الأجهزة المرتبطة > ربط جهاز'
            });
        } else {
            res.status(500).json({ error: 'Failed to generate pairing code' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إرسال رسالة
app.post('/send', async (req, res) => {
    const { phone, message } = req.body;

    if (!isConnected) {
        return res.status(400).json({ error: 'WhatsApp not connected' });
    }

    if (!phone || !message) {
        return res.status(400).json({ error: 'Phone and message required' });
    }

    try {
        // تنسيق الرقم
        // نعتمد على ما أدخله المستخدم (مفتاح الدولة + الرقم)
        // نقوم فقط بإزالة الرموز غير الرقمية
        let formattedPhone = phone.replace(/[^0-9]/g, '');

        // إزالة الأصفار في البداية (مثل 00964 تصبح 964)
        formattedPhone = formattedPhone.replace(/^0+/, '');

        const jid = formattedPhone + '@s.whatsapp.net';

        await sock.sendMessage(jid, { text: message });

        res.json({ success: true, message: 'تم إرسال الرسالة بنجاح' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إرسال رسائل متعددة
app.post('/send-bulk', async (req, res) => {
    const { messages } = req.body; // [{phone, message}, ...]

    if (!isConnected) {
        return res.status(400).json({ error: 'WhatsApp not connected' });
    }

    const results = [];

    for (const msg of messages) {
        try {
            let formattedPhone = msg.phone.replace(/[^0-9]/g, '');
            if (formattedPhone.startsWith('0')) {
                formattedPhone = formattedPhone.substring(1);
            }
            if (!formattedPhone.startsWith('964')) {
                formattedPhone = '964' + formattedPhone;
            }

            const jid = formattedPhone + '@s.whatsapp.net';
            await sock.sendMessage(jid, { text: msg.message });

            results.push({ phone: msg.phone, success: true });

            // تأخير بسيط بين الرسائل لتجنب الحظر
            await new Promise(r => setTimeout(r, 2000));
        } catch (error) {
            results.push({ phone: msg.phone, success: false, error: error.message });
        }
    }

    res.json({ results });
});

// قطع الاتصال
app.post('/disconnect', async (req, res) => {
    if (sock) {
        await sock.logout();
        sock = null;
        isConnected = false;
        pairingCode = null;
    }
    res.json({ success: true });
});

// مسح الـ Session وإعادة البدء
const fs = require('fs');
const path = require('path');

app.post('/reset', async (req, res) => {
    try {
        // قطع الاتصال الحالي
        if (sock) {
            try {
                await sock.logout();
            } catch (e) {
                console.log('Logout error (ignored):', e.message);
            }
            sock = null;
        }
        isConnected = false;
        pairingCode = null;

        // حذف ملفات الـ auth
        const authDir = path.join(__dirname, 'auth_info');
        if (fs.existsSync(authDir)) {
            fs.rmSync(authDir, { recursive: true, force: true });
            console.log('Auth directory deleted');
        }

        res.json({ success: true, message: 'Session cleared. Please reconnect.' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

async function startConnection(phoneNumber) {
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info');

    // جلب أحدث إصدار من WhatsApp Web لتجنب خطأ 405
    let version;
    try {
        const { version: latestVersion } = await fetchLatestBaileysVersion();
        version = latestVersion;
        console.log('Using WhatsApp Web version:', version);
    } catch (e) {
        console.log('Failed to fetch version, using default');
        version = [2, 3000, 1015901307]; // fallback version
    }

    sock = makeWASocket({
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, logger),
        },
        version, // استخدام أحدث إصدار
        printQRInTerminal: false,
        logger,
        browser: ['Chrome (Linux)', 'Chrome', '120.0.0'], // تغيير اسم المتصفح
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        syncFullHistory: false,
    });

    // طلب كود الربط بدلاً من QR
    if (!sock.authState.creds.registered) {
        isPairing = true; // تفعيل وضع الربط

        // تنسيق الرقم للربط
        let formattedPhone = phoneNumber.replace(/[^0-9]/g, '');

        // إزالة الأصفار في البداية
        formattedPhone = formattedPhone.replace(/^0+/, '');

        // نستخدم الرقم كما هو، مفترضين أن المستخدم أدخل مع مفتاح الدولة
        console.log('Requesting pairing code for:', formattedPhone);

        setTimeout(async () => {
            try {
                pairingCode = await sock.requestPairingCode(formattedPhone);
                console.log('Pairing Code:', pairingCode);
            } catch (err) {
                console.error('Failed to get pairing code:', err);
                isPairing = false;
            }
        }, 5000); // زيادة الانتظار إلى 5 ثواني
    }

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
            console.log('Connection closed, status:', statusCode, 'reconnect:', shouldReconnect);
            isConnected = false;

            if (shouldReconnect && !isPairing) {
                startConnection(phoneNumber);
            } else if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
                console.log('Session corrupted or logged out. Cleaning up and retrying...');
                // حذف ملفات الـ auth وإعادة المحاولة
                const fs = require('fs');
                const path = require('path');
                const authDir = path.join(__dirname, 'auth_info');
                if (fs.existsSync(authDir)) {
                    fs.rmSync(authDir, { recursive: true, force: true });
                }
                isPairing = false;
                startConnection(phoneNumber);
            } else if (isPairing) {
                console.log('In pairing mode, not reconnecting (wait for user input or manual reset)...');
                // إذا فشل الربط لأسباب أخرى، نعيد تمكين إعادة المحاولة لاحقاً
                isPairing = false;
            }
        } else if (connection === 'open') {
            console.log('Connected to WhatsApp!');
            isConnected = true;
            isPairing = false; // انتهى الربط
            pairingCode = null; // تم الاتصال، لا نحتاج الكود
        }
    });
}

// تشغيل السيرفر
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`WhatsApp Server running on port ${PORT}`);
    console.log('Endpoints:');
    console.log('  POST /connect - Start connection with phone number');
    console.log('  GET /status - Check connection status');
    console.log('  POST /send - Send single message');
    console.log('  POST /send-bulk - Send multiple messages');
    console.log('  POST /disconnect - Logout');
});
