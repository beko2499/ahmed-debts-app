# Ghazali WhatsApp Server

سيرفر إرسال رسائل واتساب التلقائي باستخدام Baileys (Phone Number Pairing)

## النشر على Render

1. Fork هذا الريبو أو ارفعه لحسابك
2. اذهب إلى [render.com](https://render.com)
3. أنشئ Web Service جديد
4. اربطه بالريبو
5. الإعدادات:
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Environment**: Node

## الـ Endpoints

| Method | URL | الوصف |
|--------|-----|-------|
| GET | /status | حالة الاتصال |
| POST | /connect | بدء الربط (يحتاج phoneNumber) |
| POST | /send | إرسال رسالة (phone, message) |
| POST | /send-bulk | إرسال رسائل متعددة |
| POST | /disconnect | قطع الاتصال |

## كيفية الاستخدام

1. انشر السيرفر على Render
2. انسخ الـ URL (مثل: `https://your-app.onrender.com`)
3. افتح تطبيق Ghazali Debts → الإعدادات → ربط واتساب
4. أدخل URL السيرفر ورقم هاتفك
5. اضغط "الحصول على كود الربط"
6. افتح واتساب → الأجهزة المرتبطة → ربط جهاز
7. اختر "الربط برقم الهاتف" وأدخل الكود

## ⚠️ تحذير
هذه الطريقة غير رسمية وقد تسبب حظر مؤقت من واتساب.

## المتطلبات
- Node.js 18+
